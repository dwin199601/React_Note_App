import React from 'react';
import notes from '../notes';


export default function Note() {
    return (
       <>
        {notes.map(values =>{
            return(
                <div className="note" key={values.key}>
                <h1>{values.title}</h1>
                <p>{values.content}</p>
                </div>
            )
        })}
         </>  

       
    )
}

// <h1>Title Here</h1>
//<p>Add a note here</p>