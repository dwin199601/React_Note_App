
import './App.css';
import Header from './component/header';
import Footer from './component/footer';
import Note from './component/note';
import "./styles.css"

function App() {
  return (
    <div className="App">
     <Header/>
     <Note/>
     <Footer/>
       
    </div>
  );
}

export default App;
