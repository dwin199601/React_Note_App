import React from 'react'

export default function Header() {
    return (
        <header>
            <h1>
                Notes
            </h1>
        </header>
    )
}

