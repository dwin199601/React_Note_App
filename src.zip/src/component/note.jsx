import React from 'react'

export default function Note() {
    return (
        <div className="note">

            <h1>Title Here</h1>
            <p>Add a note here</p>

        </div>
    )
}
