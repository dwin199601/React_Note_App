import React from 'react'

export default function Footer() {
    return (
        <div>
            <footer>
            <p>Copyright {(new Date().getFullYear())}</p>
            </footer>
        </div>
    )
}
