
import './App.css';
import Header from './componentspart2/header';
import Footer from './componentspart2/footer';
import Note from './componentspart2/note';
import "./styles.css"
import notes from './notes';

function App() {
  return (

    <div className="App">
     <Header/>
     <Note>
       </Note>
    
     <Footer/>
       
    </div>
  );
}

export default App;
