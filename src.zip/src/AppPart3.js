
import './App.css';
import Header from './componentspart3/header';
import Footer from './componentspart3/footer';
import Note from './componentspart3/note';
import "./styles.css"
import CreateArea from './componentspart3/createArea'
import React, {useState} from 'react';



function App() {

  

  return (

    <div className="App">
     <Header/>
     
     <CreateArea/>
     <Footer/>
       
    </div>
  );
}

export default App;
